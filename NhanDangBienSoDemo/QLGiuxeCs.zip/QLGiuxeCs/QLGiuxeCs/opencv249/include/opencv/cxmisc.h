#ifndef __OPENCV_OLD_CXMISC_H__
#define __OPENCV_OLD_CXMISC_H__

#include "opencv2/core/internal.hpp"

#endif
