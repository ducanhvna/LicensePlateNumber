#pragma once

// OpenCV Headers
#include <opencv\cv.h>
#include <opencv\cxcore.h>
#include <opencv\highgui.h>
#include <windows.h>
#include <vcclr.h>

using namespace System;
using namespace System::Windows::Forms;
using namespace System::Drawing;